package com.company;

public class Pool {
    public static int calculateBathCapacity(int length, int width, int height){
        return length * width * height;
    }
}
