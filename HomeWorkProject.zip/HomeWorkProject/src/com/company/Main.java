package com.company;

import javax.xml.transform.Source;
import java.sql.SQLOutput;

public class Main {

    public static void main(String[] args) {
        
	/*
        System.out.println("Hello world!");

        Factorial fac = new Factorial();
        System.out.println(fac.calculateFactorialRecur(1));
        System.out.println(fac.calculateFactorialLoop(1));

        Points point = new Points();
        System.out.println(point.getDistance(1,1,4,4));

        Triangle triangle = new Triangle();
        System.out.println(triangle.isExistTriangle(5,6,2));

        TrianglePrint print = new TrianglePrint();
        print.printing(5);

        Imt imt = new Imt();
        System.out.println(imt.calculateIndex(1.65, 65));

        Identical identical = new Identical();
        System.out.println(identical.isIdentical(identical.inputIdentical()));

        Pool pool = new Pool();
        System.out.println(pool.calculateBathCapacity(4, 5, 7));

        Exam exam = new Exam();
        int[] students = exam.scanStudents(5);
        System.out.println(exam.calculateStudents(students));

        Banks bank = new Banks();
        System.out.println(bank.findMin(bank.getBanks()));

        StringPrint stringPrint = new StringPrint();
        stringPrint.printingString();

        AreaTriangle areaTriangle = new AreaTriangle();
        System.out.println(areaTriangle.calculateArea(6, 9, 5));

        Hexagon hexagon = new Hexagon();
        System.out.println(hexagon.calculateHexagonSquare(5));

	    Discount ds = new Discount();
	    ds.calculatePriceWithDiscount();

	    Factorial factorial = new Factorial();
        System.out.println(factorial.calculateSumFactorial());

        SumMinAndMax sum = new SumMinAndMax();
        int[] array = sum.getArray();
        System.out.println(sum.calculateSumMaxAndMin(sum.findMax(array), sum.findMin(array)));
	 */
    }
}
